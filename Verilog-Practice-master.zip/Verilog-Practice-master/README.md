# Verilog-Practice

[![HitCount](https://hits.dwyl.com/xiaop1/Verilog-Practice.svg?style=flat-square)](http://hits.dwyl.com/xiaop1/Verilog-Practice) <img alt="GitHub stars" src="https://img.shields.io/github/stars/xiaop1/Verilog-Practice" />

<!-- ![visitors](https://visitor-badge.glitch.me/badge?page_id=xiaopi-verilog-practice) -->

There are some [HDLBits website][1] practices. And all of them have been verified. I really hope that my practices can help you to realize how Verilog works.

2020.4.22 - 6:09:54: All of the problems are **done**. 

And there is my [blog][2].

At the end, life is fantastic bro.

[1]: https://hdlbits.01xz.net/wiki/Main_Page
[2]: https://blog.began.me

## Star History

[![Star History Chart](https://api.star-history.com/svg?repos=xiaop1/Verilog-Practice&type=Date)](https://star-history.com/#xiaop1/Verilog-Practice&Date)
